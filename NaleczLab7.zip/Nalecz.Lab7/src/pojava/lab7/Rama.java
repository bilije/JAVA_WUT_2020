package pojava.lab7;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.HeadlessException;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextPane;

public class Rama extends JFrame {
	
	JButton check;
	JButton exit;
	
	JLabel info;
	
	JTextPane txtp;
	JPanel panel2;
	
	JMenuBar menuBar;
	JMenu menu;
	JMenuItem save;
	JMenuItem load;
	
	JMenu fontt;
	JMenuItem italic;
	JMenuItem bold;
	
	JMenu fsize;
	JMenuItem p22;
	JMenuItem p25;
	JMenuItem p30;
	
	JFileChooser chooser;
	
	String line1;
	String line2;
	
	int fs = 22;
	boolean f = true;
	
	GridBagConstraints gbl = new GridBagConstraints();

	public Rama() throws HeadlessException {
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setSize(960,480);
		setTitle("Dyktando");
		this.setLayout(new BorderLayout());
		Rama to = this;
		
		txtp = new JTextPane();
		txtp.setFont(new Font("Courier", Font.ITALIC,getFs()));
		
		this.add(txtp, BorderLayout.CENTER);
		
		
		
		chooser = new JFileChooser();
		
		menuBar = new JMenuBar();
		
		menu = new JMenu("Menu");
		
		save = new JMenuItem("Zapisz");
		save.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int result = chooser.showSaveDialog(save);
				
				if(result == JFileChooser.APPROVE_OPTION) {
					
					try {
						txtp.write( new OutputStreamWriter(
						        new FileOutputStream(chooser.getSelectedFile()),
						        Charset.forName("UTF-8").newEncoder())) ;
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				
				}else {
				
					System.out.println("Nie wybrano pliku");
				}
				
			}
		});
		
		menu.add(save);
		
		load = new JMenuItem("Wczytaj");
		load.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int result = chooser.showDialog(null, "Wybierz");
				
				if (JFileChooser.APPROVE_OPTION == result){
					
					try {
						InputStreamReader isr = new InputStreamReader(
                                new FileInputStream(chooser.getSelectedFile()),
                                Charset.forName("UTF-8").newDecoder() 
                            );
						BufferedReader br = new BufferedReader(isr);
						setLine1(br.readLine());
						setLine2(line1);
						
						setLine2(line2.replaceAll("u","?"));
						/*setLine2(line2.replaceAll("�","?"));
						setLine2(line2.replaceAll("rz","?"));
						setLine2(line2.replaceAll("�","?"));
						setLine2(line2.replaceAll("ch","?"));
						setLine2(line2.replaceAll("h","?"));*/
						
						txtp.setText(line2);
						
						
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					
					
					}else {
					System.out.println("Nie wybrano pliku");
					}
				
			}
		});
		menu.add(load);
		
		fontt = new JMenu("Czcionka");
		italic = new JMenuItem("ITALIC");
		italic.setSelected(true);
		italic.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				txtp.setFont(new Font("Courier", Font.ITALIC, getFs()));
				f = true;
				
			}
		});
		fontt.add(italic);
		
		bold = new JMenuItem("BOLD");
		bold.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				txtp.setFont(new Font("Courier", Font.BOLD, getFs()));
				f = false;
				
			}
		});
		fontt.add(bold);
		
		menu.add(fontt);
		
		
		
		fsize = new JMenu("Rozmiar czcionki");
		p22 = new JMenuItem("22");
		p22.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setFs(22);
				if(f) {
					txtp.setFont(new Font("Courier", Font.ITALIC, 22));
				}
				else {
					txtp.setFont(new Font("Courier", Font.BOLD, 22));
				}
			}
		});
		fsize.add(p22);
		
		p25 = new JMenuItem("25");
		p25.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setFs(25);
				if(f) {
					txtp.setFont(new Font("Courier", Font.ITALIC, 25));
				}
				else {
					txtp.setFont(new Font("Courier", Font.BOLD, 25));
				}
				
			}
		});
		fsize.add(p25);
		
		p30 = new JMenuItem("30");
		p30.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setFs(30);
				if(f) {
					txtp.setFont(new Font("Courier", Font.ITALIC, 30));
				}
				else {
					txtp.setFont(new Font("Courier", Font.BOLD, 30));
				}
				
			}
		});
		fsize.add(p30);
		
		menu.add(fsize);
		
		menuBar.add(menu);
		this.setJMenuBar(menuBar);
		
		
		
		info = new JLabel();
		info.setText("Zamie� ? na polskie znaki:");
		
	
	
		
		
		panel2 = new JPanel(new GridBagLayout());
		
		check = new JButton("Sprawd�");
		check.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
				try {
					if(line1.equals(txtp.getText())) {
						
						JOptionPane.showMessageDialog(to, 
								"Nie ma b��d�w!!!", "BRAWO!", JOptionPane.INFORMATION_MESSAGE);
					}
					else {
						JOptionPane.showMessageDialog(to, 
								"B��D!", "ERROR", JOptionPane.ERROR_MESSAGE);
					}
				}
				catch(NullPointerException e2) {
					JOptionPane.showMessageDialog(to, 
							"Nie wczytano pliku!", "ERROR", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		
		exit = new JButton("Zako�cz");
		exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				
			}
		});
		
		
		gbl.insets = new Insets(2,2,2,2);
		gbl.fill = GridBagConstraints.HORIZONTAL;
		
		gbl.gridx = 0;
		gbl.gridy = 0;
		gbl.gridwidth = 2;
		panel2.add(info, gbl);
		
		gbl.gridx = 0;
		gbl.gridy = 1;
		gbl.gridwidth = 2;
		panel2.add(check, gbl);
		
		gbl.gridx = 0;
		gbl.gridy = 2;
		gbl.gridwidth = 2;
		panel2.add(exit, gbl);
		
		this.add(panel2, BorderLayout.WEST);
		
	}

	public Rama(GraphicsConfiguration gc) {
		super(gc);
		// TODO Auto-generated constructor stub
	}

	public Rama(String title) throws HeadlessException {
		super(title);
		// TODO Auto-generated constructor stub
	}

	public Rama(String title, GraphicsConfiguration gc) {
		super(title, gc);
		// TODO Auto-generated constructor stub
	}

	public String getLine1() {
		return line1;
	}

	public void setLine1(String line1) {
		this.line1 = line1;
	}

	public String getLine2() {
		return line2;
	}

	public void setLine2(String line2) {
		this.line2 = line2;
	}

	public int getFs() {
		return fs;
	}

	public void setFs(int fs) {
		this.fs = fs;
	}

}
