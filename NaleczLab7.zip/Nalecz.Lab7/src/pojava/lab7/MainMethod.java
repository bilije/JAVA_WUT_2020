package pojava.lab7;

public class MainMethod {

	public static void main(String[] args) {
		
		Rama rama = new Rama();
		rama.setVisible(true);

	}

}
