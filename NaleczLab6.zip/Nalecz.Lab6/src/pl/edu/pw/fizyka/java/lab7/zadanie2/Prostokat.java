package pl.edu.pw.fizyka.java.lab7.zadanie2;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Prostokat{

    private int xPos = 50;
	private int yPos = 50;
    private int width = 20;
    private int height = 20;
    private Color color = Color.BLACK;
    private int xSpeed = 5;
    private int ySpeed = 0;
    private boolean image = false;
    
    BufferedImage[] aimage = new BufferedImage[5];
    
    
    public Prostokat() {
    	
    	
    	for(int i = 1; i < 6; i++) {
    		File inputFile = new File("nr"+i+".jpg");
    		
    		 
    		try {
    			aimage[i-1] = ImageIO.read(inputFile);
    		} catch(IOException ex) {
    			System.out.println(ex.getMessage());
    		}
    	}
    }
    
    public int getxSpeed() {
		return xSpeed;
	}

	public void setxSpeed(int xSpeed) {
		this.xSpeed = xSpeed;
	}

	public int getySpeed() {
		return ySpeed;
	}

	public void setySpeed(int ySpeed) {
		this.ySpeed = ySpeed;
	}

	
    
    
    public int getX() {
		return xPos;
	}

	public void setX(int xPos) {
		this.xPos = xPos;
	}

    public void setY(int yPos){
        this.yPos = yPos;
    }

    public int getY(){
        return yPos;
    }

    public int getWidth(){
        return width;
    } 

    public int getHeight(){
        return height;
    }


	public void setWidth(int width) {
		this.width = width;
	}

	public void setHeight(int height) {
		this.height = height;
	}

    public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public boolean isImage() {
		return image;
	}

	public void setImage(boolean image) {
		this.image = image;
	}

	public BufferedImage getAimage(int i) {
		return aimage[i];
	}

	public void setAimage(BufferedImage[] aimage) {
		this.aimage = aimage;
	}

	public void paint(Graphics g){
        g.setColor(getColor());
        g.fillRect(xPos,yPos,getWidth(),getHeight());
    }
	

}
