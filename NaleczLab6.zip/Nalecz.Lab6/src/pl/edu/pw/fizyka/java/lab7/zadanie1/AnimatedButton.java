package pl.edu.pw.fizyka.java.lab7.zadanie1;




import javax.swing.JButton;

public class AnimatedButton extends JButton implements Runnable {

	static String [] text = {"cze��", "to", "jest", "animowane"};
	int pause = 1000;
	boolean work = true;
	
	public AnimatedButton() {
		super();
		setText(text[0]);
	}


	@Override
	public void run() {
		
		int i = 0;

		while (work) {

			if (i < text.length - 1)
				i++;
			else
				i = 0;
			
			setText(text[i]);
			
			try {
				Thread.sleep(pause);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

}
