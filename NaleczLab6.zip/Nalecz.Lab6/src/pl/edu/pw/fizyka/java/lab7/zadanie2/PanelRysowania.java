package pl.edu.pw.fizyka.java.lab7.zadanie2;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import static java.util.concurrent.TimeUnit.*;

import javax.swing.JPanel;

class PanelRysowania extends JPanel {

	private static final long serialVersionUID = 1L;
	List<Prostokat> prostokaty = new ArrayList<Prostokat>();
	int iterator = 0;
	int a = 1;

	public PanelRysowania() {
       // domyslny konstruktor
	}
	
	public void dodajLosowyProstokat(){
		Random r = new Random();
		
		Prostokat p = new Prostokat();
		p.setX(r.nextInt(550));
		p.setY(r.nextInt(550));
		p.setWidth(r.nextInt(80));
		p.setHeight(r.nextInt(80));
		p.setColor(new Color(r.nextInt(255), r.nextInt(255),
				r.nextInt(255), r.nextInt(255)));
		p.setxSpeed(r.nextInt(10));
		p.setySpeed(r.nextInt(10));

		prostokaty.add(p);		
	}
	
	public void dodajProstokat(int x, int y, int width, int height, Color c, int xs, int ys){
		Prostokat p = new Prostokat();
		p.setX(x);
		p.setY(y);
		p.setWidth(width);
		p.setHeight(height);
		p.setColor(c);
		p.setxSpeed(xs);
		p.setySpeed(ys);
		p.setImage(true);

		prostokaty.add(p);		
		
	}


	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		for (Prostokat pr : prostokaty) {
			pr.paint(g);
			
			if(pr.isImage() == true) 
				g.drawImage(pr.getAimage(iterator), pr.getX(), pr.getY(), pr.getWidth(),pr.getHeight(), null);
				
			}
			
	}

	
	
	public Dimension getPreferredSize() {
		return new Dimension(600, 600);
	}

	
	public void rozpocznijRuch() {
		
		ScheduledExecutorService scheduler = 
			       Executors.newScheduledThreadPool(1);

		scheduler.scheduleAtFixedRate( (new Runnable() {
			
			@Override
			public void run() {
				

				for(int i = 0; i < prostokaty.size(); i++) {
					
					
					
					if(prostokaty.get(i).getX() > getWidth() - prostokaty.get(i).getWidth()) prostokaty.get(i).setxSpeed(-prostokaty.get(i).getxSpeed());
					if(prostokaty.get(i).getX() < 0) prostokaty.get(i).setxSpeed(-prostokaty.get(i).getxSpeed());
					
					if(prostokaty.get(i).getY() > getHeight() - prostokaty.get(i).getHeight()) prostokaty.get(i).setySpeed(-prostokaty.get(i).getySpeed());
					if(prostokaty.get(i).getY() < 0) prostokaty.get(i).setySpeed(-prostokaty.get(i).getySpeed());
					
					prostokaty.get(i).setX(prostokaty.get(i).getX() + prostokaty.get(i).getxSpeed());
					prostokaty.get(i).setY(prostokaty.get(i).getY() + prostokaty.get(i).getySpeed());
				
					
					repaint();
					
					
				}
		
					
			}
		}),  0, 15, MILLISECONDS);
	}
	
	public void rozpocznijAnimacje() {
		ScheduledExecutorService scheduler = 
			       Executors.newScheduledThreadPool(1);

		scheduler.scheduleAtFixedRate( (new Runnable() {
			
			@Override
			public void run() {
				
					if(iterator == 4) iterator = 0;
				
					iterator += a;
				
					repaint();
				
			}
		}), 0, 1, SECONDS);
		
	}
	
}
