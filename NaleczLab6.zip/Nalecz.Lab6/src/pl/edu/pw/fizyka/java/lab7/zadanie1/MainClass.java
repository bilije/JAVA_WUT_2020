package pl.edu.pw.fizyka.java.lab7.zadanie1;

import java.awt.GridLayout;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;


import static java.util.concurrent.TimeUnit.*;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class MainClass {

	static final int SLIDER_MIN = 1;
	static final int SLIDER_MAX = 5;
	static final int SLIDER_INIT = 1;
	
	public static void main(String[] args) {
		
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				JFrame frame = new JFrame();
				frame.setSize(300, 300);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setLayout(new GridLayout(3,1));
				
				
				AnimatedButton b1 = new AnimatedButton();
				frame.add(b1);
				
				AnimatedTextField txt1 = new AnimatedTextField();
				frame.add(txt1);
				
				AnimatedSlider s1 = new AnimatedSlider(SLIDER_MIN, SLIDER_MAX, SLIDER_INIT);
				s1.setMajorTickSpacing(1);
				s1.setPaintTicks(true);
				s1.setPaintLabels(true);
				frame.add(s1);
				
				
				final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(4);
				
				scheduler.scheduleWithFixedDelay(b1, 1, 1, SECONDS);
				scheduler.scheduleWithFixedDelay(txt1, 0, 1, SECONDS);
				scheduler.scheduleWithFixedDelay(s1, 1, 1, SECONDS);
				
				scheduler.schedule(new Runnable() {
	                @Override
					public void run() { 
	                scheduler.shutdownNow();
	                System.exit(0);}
	            }, 20, SECONDS);
				
			
				
				
				frame.setVisible(true);
			}
		});
		
		
	}

}
