package pl.edu.pw.fizyka.java.lab7.zadanie1;

import javax.swing.BoundedRangeModel;
import javax.swing.JSlider;

public class AnimatedSlider extends JSlider implements Runnable {

	boolean work = true;
	int value = 1;
	
	public AnimatedSlider() {
		// TODO Auto-generated constructor stub
	}

	public AnimatedSlider(int orientation) {
		super(orientation);
		// TODO Auto-generated constructor stub
	}

	public AnimatedSlider(BoundedRangeModel brm) {
		super(brm);
		// TODO Auto-generated constructor stub
	}

	public AnimatedSlider(int min, int max) {
		super(min, max);
		// TODO Auto-generated constructor stub
	}

	public AnimatedSlider(int min, int max, int value) {
		super(min, max, value);
		// TODO Auto-generated constructor stub
	}

	public AnimatedSlider(int orientation, int min, int max, int value) {
		super(orientation, min, max, value);
		// TODO Auto-generated constructor stub
	}
	
	

	@Override
	public void run() {
		
		int i = 1;
		
		while(work) {
			
			if(getValue() == 5) i = -1;
			if(getValue() == 1) i = 1;
			
			value += i;
			
			setValue(value);
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

	}

}
