package pl.edu.pw.fizyka.java.lab7.zadanie1;

import java.awt.Color;

import javax.swing.JTextField;


public class AnimatedTextField extends JTextField implements Runnable {
	
	
	int shade = 0;
	boolean work = true;
	
	public AnimatedTextField() {
		setEditable(false);
		
	}

	

	@Override
	public void run() {
		int i = 1;
		
		while(work) {
			
			if(shade == 255) i = -1;
			if(shade == 0) i = 1;
			
			shade += i;
			
			if(shade <= 85) {
				setBackground(new Color(170, shade, 85));
			}
			
			if(shade > 85 && shade <= 170) {
				
				setBackground(new Color(170 ,85, shade));
			}
			
			if(shade > 170) {
				setBackground(new Color(shade, 85  , 170));
			}
			
			try {
				Thread.sleep(2);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
