package pojava.lab4;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.JPanel;


public class FigureDrawPanel extends JPanel {
	
	

	Random r1 = new Random();
	
	List<Point> vertex = new ArrayList<Point>();
	
	public int k = 3;
	
	public int lineWidth = 5;
	

	
	Color color1 = Color.black;
	
	public FigureDrawPanel() {
		super();
		random(k);
	}

	public void paintComponent(Graphics g) {
		
		
		super.paintComponent(g);
		
		Graphics2D g2d = (Graphics2D) g;
		BasicStroke bs1 = new BasicStroke(lineWidth);
		g2d.setStroke(bs1);
		
		
		for(int i = 0; i < k-1; i++) {
			g.setColor(color1);
			if(i < k-1)
				
				g2d.drawLine(vertex.get(i).x,vertex.get(i).y, vertex.get(i+1).x, vertex.get(i+1).y);
				//System.out.println(" "+vertex.get(i).x+vertex.get(i).y+ vertex.get(i+1).x+ vertex.get(i+1).y);
			
			if(i == k-2) {
				
				
				g.drawLine(vertex.get(k-1).x,vertex.get(k-1).y, vertex.get(0).x, vertex.get(0).y);
				
			}
		}
		
			
		
		
		
	}

	public void random(int k) {
		
		vertex.clear();
		for(int i = 0; i < k; i++) {
			
			vertex.add(new Point(r1.nextInt(300),r1.nextInt(300)));
			
		}
	}

	public int getK() {
		return k;
	}

	public void setK(int k) {
		this.k = k;
		this.random(k);
	}

	public Color getColor1() {
		return color1;
	}

	public void setColor1(Color color1) {
		this.color1 = color1;
	}

	public int getLineWidth() {
		return lineWidth;
	}

	public void setLineWidth(int lineWidth) {
		this.lineWidth = lineWidth;
	}
}
