package pojava.lab4;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;



public class FiguresFrame extends JFrame  {

	static final int SLIDER_MIN = 3;
	static final int SLIDER_MAX = 33;
	static final int SLIDER_INIT = 3;
	
	JSlider slider;
	JButton changeColorButton;
	JTextField numberOfAngles;
	JLabel numberOA;
	JMenuBar menuBar;
	JRadioButton backgroundButton;
	JRadioButton lineButton;
	
	FigureDrawPanel centerPanel;
	
	Random r1 = new Random();
	
	public FiguresFrame() throws HeadlessException {
	
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setSize(600,450);
		
		slider = new JSlider(JSlider.HORIZONTAL, SLIDER_MIN, SLIDER_MAX, SLIDER_INIT);
		slider.setMajorTickSpacing(3);
		slider.setMinorTickSpacing(1);
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		slider.addChangeListener(new SliderChangeListener());
		
		
		changeColorButton = new JButton("Zmie� kolor");
		changeColorButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(lineButton.isSelected()) {
				
					Color initColor = centerPanel.getColor1();
					Color choosedColor = JColorChooser.showDialog(centerPanel, "Wybierz kolor", initColor);
					centerPanel.setColor1(choosedColor);
					repaint();
				}
				
				if(backgroundButton.isSelected()) {
					
					Color initColor = centerPanel.getBackground();
					Color choosedColor = JColorChooser.showDialog(centerPanel, "Wybierz kolor", initColor);
					centerPanel.setBackground(choosedColor);
					repaint();
				}
				
			}
		});
		numberOfAngles = new JTextField(2);
		numberOfAngles.setText("3");
		numberOA = new JLabel("Liczba k�t�w");
		
		backgroundButton = new JRadioButton("T�o");
		lineButton = new JRadioButton("Linie");
		lineButton.setSelected(true);
		ButtonGroup buttonGroup = new ButtonGroup();
		buttonGroup.add(lineButton);
		buttonGroup.add(backgroundButton);
		
		menuBar = new JMenuBar();
		JMenu menu = new JMenu("Menu");
		JMenuItem px2 = new JMenuItem("2px");
		px2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent f) {
				centerPanel.setLineWidth(2);
				repaint();
			}
		});
		
		
		menu.add(px2);
		
		JMenuItem px3 = new JMenuItem("3px");
		px3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent g) {
				centerPanel.setLineWidth(3);
				repaint();
			}
		});
		
		
		menu.add(px3);
		
		JMenuItem px5 = new JMenuItem("5px");
		px5.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent h) {
				centerPanel.setLineWidth(5);
				repaint();
			}
		});
		
		
		menu.add(px5);
		
		JMenuItem id = new JMenuItem("Autor");
		id.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent i) {
				JOptionPane.showMessageDialog(null, "Tomasz Na��cz","Autor",JOptionPane.INFORMATION_MESSAGE);
			}
		});	
		
		menu.add(id);
		menuBar.add(menu);
		

		this.setJMenuBar(menuBar);
		
		JPanel upperPanel = new JPanel();
		upperPanel.add(slider);
		upperPanel.add(numberOA);
		upperPanel.add(numberOfAngles);
		upperPanel.setLayout(new FlowLayout());
		
		this.add(upperPanel, BorderLayout.PAGE_START);
		
		centerPanel = new FigureDrawPanel();
		
		
		centerPanel.setBackground(Color.white);
		this.add(centerPanel, BorderLayout.CENTER);
		
		JPanel leftPanel = new JPanel();
		leftPanel.add(lineButton);
		leftPanel.add(backgroundButton);
		leftPanel.add(changeColorButton);
		leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
		
		this.add(leftPanel, BorderLayout.LINE_START);
		
		
	}


	
	
	public class SliderChangeListener implements ChangeListener {
		
		@Override
		public void stateChanged(ChangeEvent arg0) {
			String value = String.format("%d", slider.getValue());
			numberOfAngles.setText(value);
			
			repaint();
			revalidate();
			centerPanel.setK(slider.getValue());
		
		}
	}
	
	
	
	public static void main(String[] args) {
		FiguresFrame frame = new FiguresFrame();
		frame.setVisible(true);
		
	}

}
