package pojava.kolokwium;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class FrameK extends JFrame implements Runnable {

	JPanel northPanel;
	PanelChartK chPanel;
	JPanel centerPanel;
	
	JLabel xLabel;
	JLabel yLabel;
	
	JTextField xTxt;
	JTextField yTxt;
	
	JButton addPoint;
	JButton drawPoint;
	
	JTextArea dataTxt;
	
	String txtarea ="";
	
	JMenuBar menuBar;
	
	JScrollPane scroll;
	
	JFileChooser chooser;
	
	boolean check;
	
	public FrameK() throws HeadlessException {
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setSize(1300,700);
		setLocationRelativeTo ( null );
		
		FrameK to = this;
		
		xLabel = new JLabel("x:");
		yLabel = new JLabel("y:");
		
		xTxt = new JTextField(3);
		yTxt = new JTextField(3);
		
		addPoint = new JButton("Dodaj punkt");
		addPoint.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				check = true;
				
				try {	
					chPanel.dodane.add(new PointK( Double.valueOf(xTxt.getText()) 
												, Double.valueOf(yTxt.getText())));
				}
				catch(NumberFormatException f) {
					JOptionPane.showMessageDialog(to, 
							"Z�Y FORMAT DANYCH", "ERROR", JOptionPane.ERROR_MESSAGE);
					
					check = false;
				}
				
				if(check) {
					txtarea +="Dodano punkt x:"+xTxt.getText()+" , y:"+ yTxt.getText()+"\n";
					dataTxt.setText(txtarea);
				}
				
				repaint();
				
				
				
			}
		});
		
		drawPoint = new JButton("Losuj 10 punkt�w");
		
		northPanel = new JPanel();
		
		northPanel.add(xLabel);
		northPanel.add(xTxt);
		northPanel.add(yLabel);
		northPanel.add(yTxt);
		northPanel.add(addPoint);
		northPanel.add(drawPoint);
		
		northPanel.setLayout(new FlowLayout());
		
		this.add(northPanel, BorderLayout.NORTH);
		
		centerPanel = new JPanel();
		
		chPanel = new PanelChartK();
		chPanel.setSize(500, 300);
		
		centerPanel.add(chPanel);
		
		dataTxt = new JTextArea();
		dataTxt.setFont(new Font("Courier", Font.ITALIC,15));
		dataTxt.setEnabled(true);
		
		scroll = new JScrollPane(dataTxt);
		
		centerPanel.add(scroll);
		
		centerPanel.setLayout(new GridLayout(1,2));
		
		this.add(centerPanel, BorderLayout.CENTER);
		
		menuBar = new JMenuBar();
		JMenu menu = new JMenu("Menu");
		JMenuItem save = new JMenuItem("Zapisz");
		chooser = new JFileChooser();
		
		save.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int result = chooser.showSaveDialog(save);
				
				if(result == JFileChooser.APPROVE_OPTION) {	
					
					BufferedImage image = new BufferedImage(chPanel.getWidth(), chPanel.getHeight(),BufferedImage.TYPE_INT_ARGB);
					Graphics2D g2d = image.createGraphics();
					chPanel.paintAll(g2d);
					
					File outputfile = new File(chooser.getSelectedFile(),chooser.getName(chooser.getSelectedFile()));
					
					try {
						ImageIO.write(image, "png", outputfile);
					} catch (IOException f) {
						System.out.println(f.getMessage());
					}
				}
			}
		} );
		
		
		JMenuItem clear = new JMenuItem("Wyczy��");
		clear.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int dialogButton = JOptionPane.YES_NO_OPTION;
				int dialogResult = JOptionPane.showConfirmDialog (null, "Czy na pewno?","USUWANIE!",dialogButton);
				if(dialogResult == JOptionPane.YES_OPTION){
					chPanel.dodane.clear();
					chPanel.losowe.clear();
					repaint();
					txtarea = "";
					dataTxt.setText("");
				}
			}
		});
		
		menu.add(save);
		menu.add(clear);
		
		menuBar.add(menu);
		
		this.setJMenuBar(menuBar);
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
