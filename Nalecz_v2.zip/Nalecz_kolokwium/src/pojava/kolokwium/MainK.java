package pojava.kolokwium;

public class MainK {

	public static void main(String[] args) {
		FrameK frame = new FrameK();
		frame.setVisible(true);

	}

}
