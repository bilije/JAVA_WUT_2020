package pojava.kolokwium;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class PanelChartK extends JPanel {

	List<PointK> dodane = new ArrayList<PointK>();
	List<PointK> losowe = new ArrayList<PointK>();
	
	
	public PanelChartK() {
		this.setBackground(Color.white);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		Graphics2D g2d = (Graphics2D) g;
		BasicStroke bs1 = new BasicStroke(2);
		g2d.setStroke(bs1);
		
		if(dodane.size() != 0 && losowe.size() != 0) {
			
			this.MakeChart(MakeData(Makeseries())).draw(g2d, new Rectangle(0,0, 400,400));

		}
		
	}
	
	public XYSeries Makeseries() {
		
		XYSeries serie = new XYSeries("Wykres");
		
		
		if(dodane.size() != 0) {
			
			for(int i = 0; i < dodane.size(); i++) {
				
				serie.add(dodane.get(i).getX(),dodane.get(i).getY());	
			}
		}
		
		
		return serie;
	}
	
	public XYSeriesCollection MakeData(XYSeries x) {
		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(x);
		return dataset;
	}
	
	public JFreeChart MakeChart(XYSeriesCollection x) {
		
		JFreeChart chart = ChartFactory.createXYLineChart(
				"Wykres a*x+b",//Tytul
				"O� X", // opisy osi
				"O� Y", 
				x, // Dane 
				PlotOrientation.VERTICAL, // Orjentacja wykresu /HORIZONTAL
				true, // legenda
				true, // tooltips
				false
			);
		
		return chart;
	}



}
