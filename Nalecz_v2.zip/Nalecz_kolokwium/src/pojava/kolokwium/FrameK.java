package pojava.kolokwium;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class FrameK extends JFrame {

	JPanel northPanel;
	PanelChartK chPanel;
	JPanel centerPanel;
	
	JLabel xLabel;
	JLabel yLabel;
	
	JTextField xTxt;
	JTextField yTxt;
	
	JButton addPoint;
	JButton drawPoint;
	
	JTextArea dataTxt;
	
	
	
	
	public FrameK() throws HeadlessException {
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setSize(1300,700);
		setLocationRelativeTo ( null );
		
		xLabel = new JLabel("x:");
		yLabel = new JLabel("y:");
		
		xTxt = new JTextField(3);
		yTxt = new JTextField(3);
		
		addPoint = new JButton("Dodaj punkt");
		addPoint.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				try {	
					chPanel.dodane.add(new PointK( Double.valueOf(xTxt.getText()) 
												, Double.valueOf(yTxt.getText())));
				}
				catch(NumberFormatException f) {
					
				}
				repaint();
				
			}
		});
		
		drawPoint = new JButton("Losuj 10 punkt�w");
		
		northPanel = new JPanel();
		
		northPanel.add(xLabel);
		northPanel.add(xTxt);
		northPanel.add(yLabel);
		northPanel.add(yTxt);
		northPanel.add(addPoint);
		northPanel.add(drawPoint);
		
		northPanel.setLayout(new FlowLayout());
		
		this.add(northPanel, BorderLayout.NORTH);
		
		centerPanel = new JPanel();
		
		chPanel = new PanelChartK();
		chPanel.setSize(500, 300);
		
		centerPanel.add(chPanel);
		
		dataTxt = new JTextArea();
		dataTxt.setFont(new Font("Courier", Font.ITALIC,15));
		dataTxt.setEnabled(true);
		
		centerPanel.add(dataTxt);
		
		centerPanel.setLayout(new GridLayout(1,2));
		
		this.add(centerPanel, BorderLayout.CENTER);
		
	}

}
