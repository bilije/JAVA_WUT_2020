package pojava.kolokwium;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class FrameK extends JFrame {

	JPanel northPanel;
	JPanel chPanel;
	JPanel centerPanel;
	
	JLabel xLabel;
	JLabel yLabel;
	
	JTextField xTxt;
	JTextField yTxt;
	
	JButton addPoint;
	JButton drawPoint;
	
	JTextArea dataTxt;
	
	
	
	
	public FrameK() throws HeadlessException {
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setSize(1000,700);
		setLocationRelativeTo ( null );
		
		xLabel = new JLabel("x:");
		yLabel = new JLabel("y:");
		
		xTxt = new JTextField(3);
		yTxt = new JTextField(3);
		
		addPoint = new JButton("Dodaj punkt");
		
		drawPoint = new JButton("Losuj 10 punkt�w");
		
		northPanel = new JPanel();
		
		northPanel.add(xLabel);
		northPanel.add(xTxt);
		northPanel.add(yLabel);
		northPanel.add(yTxt);
		northPanel.add(addPoint);
		northPanel.add(drawPoint);
		
		northPanel.setLayout(new FlowLayout());
		
		this.add(northPanel, BorderLayout.NORTH);
		
		centerPanel = new JPanel();
		
		chPanel = new JPanel();
		chPanel.setBackground(Color.black);
		chPanel.setSize(500, 300);
		
		centerPanel.add(chPanel, BorderLayout.WEST);
		
		dataTxt = new JTextArea();
		dataTxt.setFont(new Font("Courier", Font.ITALIC,20));
		dataTxt.setEnabled(true);
		
		centerPanel.add(dataTxt);
		
		this.add(centerPanel, BorderLayout.CENTER);
		
	}

}
