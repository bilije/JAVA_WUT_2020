package pojava.lab9;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

public class Rama extends JFrame {

	JButton button;
	JLabel txtLabel;
	
	JTextField txtField;
	JTextArea txtArea;
	JScrollPane scroll;
	
	JPanel buttonPanel;
	JPanel northPanel;
	
	
	
	public Rama() throws HeadlessException {
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setSize(960,480);
		setTitle("Baza");
		
		buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		
		button = new JButton("Wykonaj");
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					GuzikZad1 G = new GuzikZad1(txtField.getText());
					txtArea.setText(G.getInfo());
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		
		buttonPanel.add(button);
		
		txtField = new JTextField();
		txtLabel = new JLabel("Wpisz kwerend�:");
		
		northPanel = new JPanel();
		northPanel.setLayout(new GridLayout(2,1));
		northPanel.add(txtLabel);
		northPanel.add(txtField);
		northPanel.setBorder(BorderFactory.createLineBorder(Color.black, 3, true));
		
		
		txtArea = new JTextArea();
		txtArea.setFont(new Font("Courier", Font.ITALIC,20));
		txtArea.setEnabled(true);
		//txtArea.setLineWrap(true);
		   
		scroll = new JScrollPane(txtArea);
		scroll.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );
		
		//this.pack ();
	    this.setLocationRelativeTo ( null );
		this.setLayout(new BorderLayout());
		this.add(buttonPanel, BorderLayout.WEST);
		this.add(northPanel, BorderLayout.NORTH);
		this.add(scroll, BorderLayout.CENTER);
		//this.add(scroll, BorderLayout.EAST);

	}

}
