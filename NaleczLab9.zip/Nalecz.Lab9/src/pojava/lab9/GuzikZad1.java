package pojava.lab9;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class GuzikZad1 {

	
	String info;
	
	public GuzikZad1(String kwerenda) throws SQLException {
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(
					"jdbc:h2:./data/nazwabazy", "sa",
					"");


			Statement statement = conn.createStatement();
			
			
			statement.execute(kwerenda);
			
			
		
			
			ResultSet rs = statement.getResultSet();
			
			ResultSetMetaData md  = rs.getMetaData();
					

			for (int ii = 1; ii <= md.getColumnCount(); ii++){
				if(ii == 1) {
					info = md.getColumnName(ii)+ " | ";
				}
				else {
					info += md.getColumnName(ii)+ " | ";						
				}
			}
			info+="\n";
			
			while (rs.next()) {
				for (int ii = 1; ii <= md.getColumnCount(); ii++){
					info += rs.getObject(ii) + " | ";							
				}
				info += "\n";
			}
			
			System.out.println(info);
		
			
		} finally {
			if (conn!= null){
				conn.close();
			}
		}
		
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

}
