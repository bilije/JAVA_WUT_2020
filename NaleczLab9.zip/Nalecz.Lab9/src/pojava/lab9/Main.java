package pojava.lab9;

public class Main {


	public static void main(String[] args) {
		Rama frame = new Rama();
		frame.setVisible(true);
		

	}

}
