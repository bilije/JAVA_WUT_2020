package pojava.lab9.zad2;

public class MainZad2 {

	public static void main(String[] args) {
		Rama frame = new Rama();
		frame.setVisible(true);

	}

}
