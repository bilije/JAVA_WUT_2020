package przyklady;

import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.Color;
import javax.swing.JComboBox;
import java.awt.BorderLayout;



public class OuterClassListenerFrame extends JFrame {

		public OuterClassListenerFrame() throws HeadlessException {
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(300,100);
		
		String[] colors = {"red", "green", "blue"};
		
		JComboBox<String> colorList = new JComboBox<String>(colors);
		//colorList.addItemListener(new ComboBoxItemListener((JPanel)this.getContentPane()));
		add(colorList, BorderLayout.PAGE_START);
        getContentPane().setBackground(Color.red);
        colorList.addItemListener(new ComboBoxItemListener((JPanel)this.getContentPane()));
	
	}
		
        public static void main(String[] args) {
		OuterClassListenerFrame frame = new OuterClassListenerFrame();
		frame.setVisible(true);

	}

}
