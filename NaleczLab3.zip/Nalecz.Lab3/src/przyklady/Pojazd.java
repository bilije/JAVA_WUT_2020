package przyklady;

public interface Pojazd {
	
	public void start();
	public void stop();
	public void ustawPredkosc(double[] v);
}
