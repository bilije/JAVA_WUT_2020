package pojava.lab3;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class MedianFrame extends JFrame {
	
	
	List<Double> real; 
	JTextField txtField; 
	JLabel median;
	JLabel set; 
	JButton dodaj; 
	JButton mediana;
	
	public MedianFrame() {
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(520,140);
		
		real = new ArrayList<Double>();
		txtField = new JTextField("          ");
		median = new JLabel();
		set = new JLabel("Pusty");
		dodaj = new JButton("Dodaj");
		
		try {
			ActionListener dodanie = new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					
					String setto = " ";
					
					real.add(Double.valueOf(txtField.getText()));
					Collections.sort(real);
					int k = real.size();
					
					for(int i = 0 ; i < k; i++) {
						
						setto = setto.concat(Double.toString(real.get(i))+ ", ");
						
						set.setText("Zbior:" + setto);
					
					}			
				}
			};
			dodaj.addActionListener(dodanie);
		}
		
		catch(NumberFormatException exception) {
			System.exit(0);
		}
		
		mediana = new JButton("Mediana");
		ActionListener obliczMediane = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				int sum = real.size();
				Collections.sort(real); //mediana nie dziala bo lista nie sortuje sie w tym miejscu
				
				if(sum%2 == 0) {
					
					
					
					Double med = (real.get(sum/2) + real.get(sum/2+1))/2;
					
					median.setText("= "+ med);
				}	
				
				else {
					
					sum = (sum+1)/2;
					median.setText(Double.toString(real.get(sum)));
				}
				
			
			}
		};
		mediana.addActionListener(obliczMediane);
		
		
		JPanel panel1 = new JPanel(new FlowLayout());
		panel1.add(txtField);
		panel1.add(dodaj);
		panel1.add(mediana);
		panel1.add(median);
		
		JPanel panel2 = new JPanel();
		panel2.add(set);
		
		add(panel1);
		add(panel2);
		
		setLayout(new GridLayout(2,1));
		
	}

	public static void main(String[] args) {
		
		MedianFrame frame = new MedianFrame();
		frame.setVisible(true);
		
	}

}
