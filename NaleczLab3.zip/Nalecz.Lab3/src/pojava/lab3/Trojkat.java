package pojava.lab3;

import java.lang.StrictMath;

public class Trojkat implements Figura {
	
	double side1;
	double side2;
	double side3;
	
	public Trojkat(double bok1, double bok2, double bok3) {
		
		side1 = bok1;
		side2 = bok2;
		side3 = bok3;
	}

	@Override
	public double obliczObwod() {
		
		double obw = 0;
		obw = side1 + side2+ side3;
		
		return obw;
	}

	@Override
	public double obliczPole() {
		double p = 0;
		double k = (side1 + side2 + side3)/2;
		
		p = k*(k - side1)*(k - side2)*(k - side3); //nie dziala metoda sqrt z matha
		
		return p;
	}

}
