package pojava.lab3;

public class Kolo implements Figura {

	double radius; 
	
	public Kolo(double r) {
		
		radius = r;
	}

	@Override
	public double obliczObwod() {
		
		double obw = 0;
		
		obw = 2*PI*radius;
		
		return obw;
	}

	@Override
	public double obliczPole() {
		
		double p = 0;
		
		p = PI*radius*radius;
		
		return p;
	}

}
