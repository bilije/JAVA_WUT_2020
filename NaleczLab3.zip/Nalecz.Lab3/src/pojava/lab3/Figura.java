package pojava.lab3;

public interface Figura {

	public double obliczObwod();
	public double obliczPole();
	public static final double PI = 3.1415926545;
}
