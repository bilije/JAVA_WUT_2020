package pojava.lab3;

public class ZadanieA {


	public static void main(String[] args) {
		
		Kolo circle = new Kolo(3);
		Trojkat triangle = new Trojkat(3,4,5);
		
		System.out.println("Kolo: obwod = " + circle.obliczObwod() + " pole = " + circle.obliczPole());
		System.out.println("Trojkat: obwod = " + triangle.obliczObwod() + " pole = " + triangle.obliczPole());
	}

}
