package pojava.lab3;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.JColorChooser;

import przyklady.InnerClassListenerFrame.SliderChangeListener;

public class MultiListenerFrame extends JFrame implements ActionListener {

	static final int SLIDER_MIN = 0;
	static final int SLIDER_MAX = 100;
	static final int SLIDER_INIT = 0;
	
	JSlider slider;
	JButton colorButton;
	JRadioButton panelButton1;
	JRadioButton panelButton2;
	JRadioButton panelButton3;
	JTextField txtField;
	JLabel panelLabel;
	JLabel sliderLabel;
	int k = 2;
	
	public MultiListenerFrame() throws HeadlessException {
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setSize(840,680);
		
		slider = new JSlider(JSlider.HORIZONTAL, SLIDER_MIN, SLIDER_MAX, SLIDER_INIT);
		slider.setMajorTickSpacing(20);
		slider.setMinorTickSpacing(5);
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		slider.addChangeListener(new SliderChangeListener());
		
		colorButton = new JButton("Wybierz kolor");
		
		JPanel panelTop = new JPanel();
		JPanel panelCenter = new JPanel();
		JPanel panelBot = new JPanel();
		
		ActionListener colorChange = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				if( k==1 ) {
					Color initColor = panelTop.getBackground();
					Color choosedColor = JColorChooser.showDialog(panelTop, "Wybierz kolor", initColor);
					panelTop.setBackground(choosedColor);	
				}
				
				
				if( k==2 ) {
					Color initColor = panelCenter.getBackground();
					Color choosedColor = JColorChooser.showDialog(panelCenter, "Wybierz kolor", initColor);
					panelCenter.setBackground(choosedColor);	
				}
				
				if( k==3 ) {
					Color initColor = panelBot.getBackground();
					Color choosedColor = JColorChooser.showDialog(panelBot, "Wybierz kolor", initColor);
					panelBot.setBackground(choosedColor);	
				}
			}	
		};
		colorButton.addActionListener(colorChange);
		
		
		
		panelButton1 = new JRadioButton("Gorny");
		panelButton1.setActionCommand("1");
		panelButton1.addActionListener(this);
		
		panelButton2 = new JRadioButton("Srodkowy");
		panelButton2.setActionCommand("2");
		panelButton2.setSelected(true);
		panelButton2.addActionListener(this);
		
		panelButton3 = new JRadioButton("Dolny");
		panelButton3.setActionCommand("3");
		panelButton3.addActionListener(this);
		
		ButtonGroup group = new ButtonGroup();
		
		group.add(panelButton1);
		group.add(panelButton2);
		group.add(panelButton3);
		
		txtField = new JTextField(String.format("%d", slider.getValue()));
		
		panelLabel = new JLabel("Wybor panelu");
		sliderLabel = new JLabel("Wartosc");
		
		
		
		
		JPanel panelLeft = new JPanel();
		JPanel panelRight = new JPanel();
		
		//JPanel panelCenter = new JPanel();
		//JPanel panelBot = new JPanel();
		//JPanel panelTop = new JPanel();
		
		panelLeft.add(panelLabel);
		panelLeft.add(panelButton1);
		panelLeft.add(panelButton2);
		panelLeft.add(panelButton3);	
		panelLeft.setLayout(new GridLayout(4,1));
		
		panelRight.add(sliderLabel);
		panelRight.add(txtField);
		panelRight.setLayout(new BoxLayout(panelRight, BoxLayout.Y_AXIS));
		
		
		panelCenter.setBackground(Color.white);
		
		panelBot.add(colorButton);
		
		panelTop.add(slider);
		
		this.add(panelLeft, BorderLayout.LINE_START);
		this.add(panelRight, BorderLayout.LINE_END);
		this.add(panelCenter, BorderLayout.CENTER);
		this.add(panelBot, BorderLayout.PAGE_END);
		this.add(panelTop, BorderLayout.PAGE_START);
		
		slider.addChangeListener(new SliderChangeListener());
		
	}
	
	public class SliderChangeListener implements ChangeListener {
		
		@Override
		public void stateChanged(ChangeEvent arg0) {
			String value = String.format("%d", slider.getValue());
			txtField.setText(value);
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		k = Integer.parseInt(arg0.getActionCommand());
		
	}

	public static void main(String[] args) {
		MultiListenerFrame frame = new MultiListenerFrame();
		frame.setVisible(true);
		System.out.println(frame.k);

	}

}
