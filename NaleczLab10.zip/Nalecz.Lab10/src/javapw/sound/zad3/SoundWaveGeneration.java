package javapw.sound.zad3;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class SoundWaveGeneration extends JFrame {
	
	JTextField timeTxt;
	JTextField hzTxt;
	
	JLabel timeLabel;
	JLabel hzLabel;
	
	JButton startButton;
	
	public SoundWaveGeneration() {
		setSize(400,150);
    	setDefaultCloseOperation(EXIT_ON_CLOSE);
    	SoundWaveGeneration to = this;
    	
    	
    	hzLabel = new JLabel("Cz�stotliwo�� dzwi�ku (Hz):");
    	hzTxt = new JTextField(6);
    	
    	timeLabel = new JLabel("Czas trwania dzwieku (s):");
    	timeTxt = new JTextField(6);
    	
    	startButton = new JButton("Start");
    	startButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					to.dzwiek(Float.parseFloat(hzTxt.getText()), Integer.parseInt(timeTxt.getText()));
					
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (LineUnavailableException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
    	
    	
    	this.add(hzLabel);
    	this.add(hzTxt);
    	this.add(timeLabel);
    	this.add(timeTxt);
    	this.add(startButton);
    	
    	this.setLayout(new GridLayout(3,2));
	}
	
	
	public void dzwiek(float hz, int time) throws LineUnavailableException{
		 byte[] buf = new byte[1];
		    
		  //Otworz wyjscie audio
		    AudioFormat audioFormat = new AudioFormat( (float )44100, 8, 1, true, false );
		    // 44100: audio sampling rate (czestotliwosc probkowania, dla cyfrowego dzwieku standard 44100 Hz)
		    // 8: bit samples
		    
		    SourceDataLine sdl = AudioSystem.getSourceDataLine(audioFormat);
		    sdl.open();
		    sdl.start();
		    
		    //Przy kazdym przejsciu glowna petla wypelnia wolna przestrzen w buforze audio
		    for( int i = 0; i < time*1000 * (float )44100 / 1000; i++ ) {
		        double angle = i / ( (float )44100 / hz  ) * 2.0 * Math.PI;
		        buf[ 0 ] = (byte )( Math.sin( angle ) * 100 ); //nasza fala sinusoidalna
		     	        
		        sdl.write( buf, 0, 1 );
		    }
		    
		    //Zakonczono odtwarzanie fali dzwiekowej, teraz czekamy az zakolejkowane probki zakoncza
		    //odtwarzanie; nastepnie sprzatamy i wychodzimy
		    sdl.drain();
		    sdl.stop();
	}
	
	public static void main(String[] args) throws LineUnavailableException {
		SoundWaveGeneration frame = new SoundWaveGeneration();
		frame.setVisible(true);

	}

}
