package javapw.sound.zad2;

import javax.sound.sampled.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JSlider;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import static java.util.concurrent.TimeUnit.MILLISECONDS;
import static java.util.concurrent.TimeUnit.SECONDS;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
 
/**
 * A sample program is to demonstrate how to record sound in Java
 * author: www.codejava.net
 */
public class JavaSoundRecorder extends JFrame implements Runnable {
	
	
	//JavaSoundRecorder to = this;
	
    // record duration, in milliseconds
    static long RECORD_TIME = 5000;  // 5 seconds
    
    int a = 2;
    
    // path of the wav file
     File wavFile = new File("TestRecordAudio.wav");
 
    // format of audio file
    AudioFileFormat.Type fileType = AudioFileFormat.Type.WAVE;
 
    // the line from which audio data is captured
    TargetDataLine line;
 
    /**
     * Defines an audio format
     */
    AudioFormat getAudioFormat() {
        float sampleRate = 16000;
        int sampleSizeInBits = 8;
        int channels = 2;
        boolean signed = true;
        boolean bigEndian = true;
        AudioFormat format = new AudioFormat(sampleRate, sampleSizeInBits,
                                             channels, signed, bigEndian);
        return format;
    }
 
    /**
     * Captures the sound and record into a WAV file
     */
    void start() {
        try {
            AudioFormat format = getAudioFormat();
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
 
            // checks if system supports the data line
            if (!AudioSystem.isLineSupported(info)) {
                System.out.println("Line not supported");
                System.exit(0);
            }
            line = (TargetDataLine) AudioSystem.getLine(info);
            line.open(format);
            line.start();   // start capturing
 
            System.out.println("Start capturing...");
 
            AudioInputStream ais = new AudioInputStream(line);
 
            System.out.println("Start recording...");
 
            // start recording
            AudioSystem.write(ais, fileType, wavFile);
 
        } catch (LineUnavailableException ex) {
            ex.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        
        System.out.println("HALLOOO");
    }
 
    /**
     * Closes the target data line to finish capturing and recording
     */
    void finish() {
        line.stop();
        line.close();
        System.out.println("Finished");
    }
 
    
    
    
    JButton startButton;
    JSlider timeSlider;
    static final int SLIDER_MIN = 2;
	static final int SLIDER_MAX = 10;
	static final int SLIDER_INIT = 2;
    
    
    public JavaSoundRecorder() {
    	setDefaultCloseOperation(EXIT_ON_CLOSE);
    	setSize(500,400);
    	JavaSoundRecorder to = this;
    	
    	
    	startButton = new JButton("Start");
    	startButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(4);
				
				scheduler.scheduleWithFixedDelay(to, a, a+1, SECONDS);
				to.start();
				
			}
		});
    	
    	this.add(startButton);
    	
    	timeSlider = new JSlider(SLIDER_MIN, SLIDER_MAX, SLIDER_INIT);
    	timeSlider.setMajorTickSpacing(1);
		timeSlider.setPaintTicks(true);
		timeSlider.setPaintLabels(true);
    	timeSlider.addChangeListener(new ChangeListener() {
			
			@Override
			public void stateChanged(ChangeEvent e) {
				
				a = timeSlider.getValue();
			}
		});
    	
    	this.add(timeSlider);
    	
    	this.setLayout(new FlowLayout());
    	
    	
    }
    
    /**
     * Entry to run the program
     */
    public static void main(String[] args) {
        final JavaSoundRecorder recorder = new JavaSoundRecorder();
        recorder.setVisible(true);
    }

	@Override
	public void run() {
		this.finish();
        //scheduler.shutdownNow();
        System.exit(0);
		
	}
}