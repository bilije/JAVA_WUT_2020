/*	
 * 	Tomasz Nalecz
 * 	305 045
 * 	Fizyka Techniczna PO 06
 */	
package pojava.lab1.kTaxi;
import java.util.Random;
import	pojava.lab1.kAuto.Auto;

public class Taxi extends Auto  // dziedziczenie z klasy Auto
{
	float [] zarobki;
	
	Taxi()
	{
		
		zarobki = new float[12];
		
		Random random = new Random();
		
		for(int i = 0; i < zarobki.length; i++)
		{
			zarobki[i] = random.nextFloat() * (3000 - 1500) + 1500;  // tak samo jak w klasie Auto, zakres od 1500 do 3000
		}
		
	}
	
	public float srZarobki() // metoda zwracajaca srednia, taka sama jak w klasie Auto
	{
		float average = 0;
		
		for(int i = 0; i < zarobki.length; i++)
		{
			average = average + zarobki[i];
		}
		
		average = average/zarobki.length;
		
		return average;
	}
	
	public static void main(String[] args) // metoda main
	{
		Taxi TaxiDriver = new Taxi(); // utworzenie obiektu klasy Taxi
		
		float avcourse = TaxiDriver.srPrzebieg(); // wykorzystanie metody liczacej sredni przebieg
		float avpay = TaxiDriver.srZarobki();	  // wykorzystanie metody liczacej srednie zarobki
		
		System.out.println("Sredni przebieg: " + avcourse + " km"); 
		System.out.println("Srednie zarobki: " + avpay + " PLN");
	}
};




