/*	
 * 	Tomasz Nalecz
 * 	305 045
 * 	Fizyka Techniczna PO 06
 */	
package pojava.lab1.zadA;

public class Hello 
{
	public static void main (String [] args)
	{
		if(args.length != 0)  // jesli tablica stringow args nie jest pusta to wykonuje dane zadanie
		{
			System.out.println("Witaj!");  
			for( int i = 0; i < args.length; i++ ) // wykorzystanie funkcji zwracaj�cej wielkosc tablicy
			{
				int myInt = Integer.parseInt(args[i]);	// zamiana string na int i wypisanie argumentu
				System.out.println(myInt);
			}
		}
		
		else								// jesli tablica args jest pusta wyskakuje "blad"
			System.out.println("B��d!");
		
	}

};
