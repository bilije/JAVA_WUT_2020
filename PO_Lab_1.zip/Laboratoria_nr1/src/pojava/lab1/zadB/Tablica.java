/*	
 * 	Tomasz Nalecz
 * 	305 045
 * 	Fizyka Techniczna PO 06
 */	
package pojava.lab1.zadB;

public class Tablica
{
	public static void main (String [] args)
	{
		if(args.length != 0)
		{
			String [] tablica = new String[4]; // utworzenie tablicy 4 elemntowej stringow
			
			for( int i = 0; i < tablica.length; i++ )
			{
				tablica[i] = args[i]; // zapisanie argumentow metody main do nowej tablicy
				
			}
			
			for( int i = 0; i < tablica.length; i++ ) // wypisanie tablicy
			{
				System.out.println(tablica[i]);
			}
		}
		
		else								// tak samo jak w klasie Hello 
			System.out.println("B��d!");
	}
};
