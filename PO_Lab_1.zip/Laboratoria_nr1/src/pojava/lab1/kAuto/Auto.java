/*	
 * 	Tomasz Nalecz
 * 	305 045
 * 	Fizyka Techniczna PO 06
 */	
package pojava.lab1.kAuto;
import java.util.Random;

public class Auto 
{
	float [] przebieg;
	
	public Auto()  // konstruktor 
	{
		przebieg = new float[12];
		
		Random random = new Random();            // utworzenie obiektu klasy Random do losowania liczb
		
		for(int i = 0; i < przebieg.length; i++)
		{			      						 
			przebieg[i] = random.nextFloat() * (10000 - 1000) + 1000;	// wylosowanie float'ow z zakresu od 1000 do 10000
		}
	}
	
	public float srPrzebieg()	// metoda klasy zwracajaca srednia z tablicy "przebieg"
	{
		float average = 0;
		
		for(int i = 0; i < przebieg.length; i++)
		{
			average = average + przebieg[i];
		}
		
		average = average/przebieg.length;
		
		return average;
	}
	
};
