package pojava.paint;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

public class PainPanel extends JPanel implements MouseListener, MouseMotionListener {
	
	int x1 = 0; 
	int y1 = 0; 
	
	int x2 = 0;
	int y2 = 0;
	
	int check = 0;
	
	Color lineColor = Color.black; 
	
	int lineThick = 3; 
	
	
	List<Draw> pencil = new ArrayList<Draw>(); 
	List<Draw> square = new ArrayList<Draw>();
	List<Draw2> rectangle = new ArrayList<Draw2>();
	
	
	BufferedImage loadImage;
	
	public PainPanel() {
		this.setBackground(Color.white);
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		
	}

	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		
		if(check == 4) {
			Graphics2D g2d = (Graphics2D) g;
			g2d.drawImage(loadImage, 0, 0, this);
		}
		
		else {
			Graphics2D g2d = (Graphics2D) g;
			BasicStroke bs1 = new BasicStroke(lineThick);
			g2d.setStroke(bs1);
			g2d.setColor(lineColor);
			
			if(square.size() != 0) {
				
				for(int i = 0; i < square.size(); i++) {
					
					bs1 = new BasicStroke(square.get(i).getThick());
					g2d.setStroke(bs1);
					g2d.setColor(square.get(i).getColor());
				
					g2d.drawLine(square.get(i).getX() - 25, square.get(i).getY() + 25, square.get(i).getX() + 25 , square.get(i).getY() + 25);
					g2d.drawLine(square.get(i).getX() + 25, square.get(i).getY() + 25, square.get(i).getX() + 25 , square.get(i).getY() - 25);
					g2d.drawLine(square.get(i).getX() + 25, square.get(i).getY() - 25, square.get(i).getX() - 25 , square.get(i).getY() - 25);
					g2d.drawLine(square.get(i).getX() - 25, square.get(i).getY() - 25, square.get(i).getX() - 25 , square.get(i).getY() + 25);
				}
			}
				
			
			if(pencil.size() != 0) {
				
				
				
				
				for(int i = 0; i < pencil.size(); i++) {
					
					g2d.setColor(pencil.get(i).getColor());
				
					g2d.fillOval(pencil.get(i).getX(), pencil.get(i).getY(), pencil.get(i).getThick(), pencil.get(i).getThick());
				
				}	
			}
				
			
			if(rectangle.size() != 0) {
				
				for(int i = 0; i < rectangle.size(); i++) {
					
					
						bs1 = new BasicStroke(rectangle.get(i).getThick());
						g2d.setStroke(bs1);
						g2d.setColor(rectangle.get(i).getColor());
					
						g2d.drawLine(rectangle.get(i).getX(), rectangle.get(i).getY() , rectangle.get(i).getX2()  , rectangle.get(i).getY());
						g2d.drawLine(rectangle.get(i).getX2() , rectangle.get(i).getY() , rectangle.get(i).getX2(), rectangle.get(i).getY2() );
						g2d.drawLine(rectangle.get(i).getX2() , rectangle.get(i).getY2() , rectangle.get(i).getX()  , rectangle.get(i).getY2() );
						g2d.drawLine(rectangle.get(i).getX() , rectangle.get(i).getY2() , rectangle.get(i).getX() , rectangle.get(i).getY());
					
				}
			}
					
				
			
		}
	}
	
	
	
	//			MOUSE LISTENER			//
	
	
	public BufferedImage getLoadImage() {
		return loadImage;
	}

	public void setLoadImage(BufferedImage loadImage) {
		this.loadImage = loadImage;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
	
		
		if(this.getCheck() == 1) {
			square.add(new Draw(e.getX(), e.getY(), this.getLineThick(), this.getLineColor()));
			
			repaint();
		}
		
		
		if(this.getCheck() == 2) {
			
			this.setX1(e.getX());
			this.setY1(e.getY());
			
			pencil.add(new Draw(e.getX(), e.getY(), this.getLineThick(), this.getLineColor()));
			
			
			repaint();
			
		}
		
		if(this.getCheck() == 3) {
			this.setX1(e.getX());
			this.setY1(e.getY());
			
		}

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		
		System.out.println(this.getCheck());
		
		if(this.getCheck() == 3) {
		
			this.setX2(e.getX());
			this.setY2(e.getY());
			
			System.out.println("Elo");
			
			rectangle.add(new Draw2(this.getX1(), this.getY1(), this.getX2(), this.getY2(), this.getLineThick(), this.getLineColor()));
			
			repaint();
		}
	
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		//System.out.println("Entered");

	}

	@Override
	public void mouseExited(MouseEvent e) {
		//System.out.println("Exited");

	}
	
	
	
	//				MOUSE MOTION LISTENER				//
	@Override
	public void mouseMoved(MouseEvent e) {
		
		
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		//System.out.println("Dragged");

		if(this.getCheck() == 2) {
			
			this.setX1(e.getX());
			this.setY1(e.getY());
			
			pencil.add(new Draw(e.getX(), e.getY(), this.getLineThick(), this.getLineColor()));
			
			repaint();
			
		}
		
		if(this.getCheck() == 3) {
			
			System.out.println("Dragged");
			
			this.setX2(e.getX());
			this.setY2(e.getY());
			
			
			rectangle.add(new Draw2(this.getX1(), this.getY1(), this.getX2(), this.getY2(), this.getLineThick(), this.getLineColor()));
			
			repaint();
			
			rectangle.remove(rectangle.size()-1);
		}
		
	}
	
	
	
	//				GETTERS AND SETTERS				//
	
	public int getX1() {
		return x1;
	}

	public void setX1(int x) {
		this.x1 = x;
	}

	public int getY1() {
		return y1;
	}

	public void setY1(int y) {
		this.y1 = y;
	}

	

	public int getX2() {
		return x2;
	}

	public void setX2(int x2) {
		this.x2 = x2;
	}

	public int getY2() {
		return y2;
	}

	public void setY2(int y2) {
		this.y2 = y2;
	}

	public int getCheck() {
		return check;
	}

	public void setCheck(int check) {
		this.check = check;
	}

	public Color getLineColor() {
		return lineColor;
	}

	public void setLineColor(Color lineColor) {
		this.lineColor = lineColor;
	}

	public int getLineThick() {
		return lineThick;
	}

	public void setLineThick(int lineThick) {
		this.lineThick = lineThick;
	}

	

	
}
