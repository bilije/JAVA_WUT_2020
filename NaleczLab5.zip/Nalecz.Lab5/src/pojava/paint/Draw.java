package pojava.paint;

import java.awt.Color;

public class Draw {

	int x = 0;
	int y = 0;
	int thick = 0;
	Color color = Color.black;
	
	public Draw(int xx, int yy, int t, Color c) {
		
		this.x = xx;
		this.y = yy;
		this.thick = t;
		this.color  = c;
	}


	
	
	
	
	//			GETTERS AND SETTERS			//
	public int getThick() {
		return thick;
	}



	public void setThick(int thick) {
		this.thick = thick;
	}



	public int getX() {
		return x;
	}



	public void setX(int x) {
		this.x = x;
	}



	public int getY() {
		return y;
	}



	public void setY(int y) {
		this.y = y;
	}






	public Color getColor() {
		return color;
	}






	public void setColor(Color color) {
		this.color = color;
	}

}
