package pojava.paint;

public class MainMethod {

	public static void main(String[] args) {
		MainFrame frame = new MainFrame();
		frame.setVisible(true);

	}

}
