package pojava.paint;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.HeadlessException;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class MainFrame extends JFrame {

	PainPanel drawPanel;
	JPanel menuPanel;
	
	JButton colorButton;
	JButton pencilButton;
	JButton squareButton;
	JButton rectangleButton;
	JButton clearButton;
	JButton colorBCKButton;
	//JButton save;
	
	JMenuBar menuBar;
	JMenu menu;
	JMenuItem save;
	JMenuItem load;
	
	JTextField colorTxt;
	JTextField colorbcktxt;
	
	JComboBox thicknessBox;
	static String [] thickString = {"2px" , "3px" , "5px", "7px"};
	static int [] thickInt = {2, 3, 5, 7};
	
	GridBagConstraints gbl = new GridBagConstraints();
	
	public MainFrame() throws HeadlessException {
		
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setSize(840,630);
		
		drawPanel = new PainPanel();
		
		this.add(drawPanel, BorderLayout.CENTER);
		
		menuPanel = new JPanel();
		
		this.add(menuPanel, BorderLayout.WEST);
		
		menuBar = new JMenuBar();
		
		menu = new JMenu("Menu");
	
		save = new JMenuItem("Zapisz");
		save.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				BufferedImage image = new BufferedImage(drawPanel.getWidth(), drawPanel.getHeight(),BufferedImage.TYPE_INT_ARGB);
				Graphics2D g2d = image.createGraphics();
				drawPanel.paintAll(g2d);
				
				File outputfile = new File("saved" + ".png");
				
				
				try {
					ImageIO.write(image, "png", outputfile);
				} catch (IOException f) {
					System.out.println(f.getMessage());
				}
			
				
			}
		});
		menu.add(save);
		
		load = new JMenuItem("Wczytaj");
		load.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				BufferedImage image2 = null;
									
				
				File inputFile = new File("saved"+".png");
									
				 
				try {
					image2 = ImageIO.read(inputFile);
				} catch(IOException ex) {
					System.out.println(ex.getMessage());
				}
					
				drawPanel.setLoadImage(image2);
				drawPanel.setCheck(4);
				
				repaint();
				
			}
		});
		menu.add(load);
		
		menuBar.add(menu);
		
		this.setJMenuBar(menuBar);
		
		
		colorTxt = new JTextField(2);
		colorTxt.setBackground(drawPanel.getLineColor());
		colorTxt.setEditable(false);
		
		
		
		
		
		
		colorButton = new JButton("Kolor");
		colorButton.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent e) {
						
						Color initColor = drawPanel.getLineColor();
						Color choosedColor = JColorChooser.showDialog(drawPanel, "Wybierz kolor", initColor);
						drawPanel.setLineColor(choosedColor);
						colorTxt.setBackground(choosedColor);
						
					}
				});
		
		
		
		
		colorbcktxt = new JTextField(2);
		colorbcktxt.setBackground(drawPanel.getBackground());
		colorbcktxt.setEditable(false);
		colorBCKButton = new JButton("T�o");
		colorBCKButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Color initColor = drawPanel.getLineColor();
				Color choosedColor = JColorChooser.showDialog(drawPanel, "Wybierz kolor", initColor);
				colorbcktxt.setBackground(choosedColor);
				drawPanel.setBackground(choosedColor);
				
			}
		});
		
		
		
		
		squareButton = new JButton("Kwadrat");
		squareButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				drawPanel.setCheck(1);
				
			}
		});
		
		
		pencilButton = new JButton("O��wek");
		pencilButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				drawPanel.setCheck(2);
				
			}
		});
		
		rectangleButton = new JButton("Prostok�t");
		rectangleButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				drawPanel.setCheck(3);
				
			}
		});
		
		clearButton = new JButton("Wyczy��");
		clearButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				drawPanel.pencil.clear();
				drawPanel.square.clear();
				drawPanel.rectangle.clear();
				drawPanel.setBackground(Color.white);
				repaint();
				
			}
		});
		
		
		thicknessBox = new JComboBox(thickString);
		thicknessBox.setSelectedItem(thickString[1]);
		thicknessBox.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				for(int i = 0; i < 4; i++) {
					
					if(thicknessBox.getSelectedItem() == thickString[i]) {
						
						drawPanel.setLineThick(thickInt[i]);
					}
					
				}
				
			}
		});
		
		
		
		menuPanel.setLayout(new GridBagLayout());
		
		gbl.insets = new Insets(2,2,2,2);
		gbl.fill = GridBagConstraints.HORIZONTAL;
		
		gbl.gridx = 0;
		gbl.gridx = 0;
		gbl.gridwidth = 2;
		menuPanel.add(rectangleButton, gbl);
		
		gbl.gridx = 0;
		gbl.gridy = 1;
		gbl.gridwidth = 1;
		menuPanel.add(squareButton, gbl);
		
		gbl.gridx = 1;
		gbl.gridy = 1;
		menuPanel.add(pencilButton, gbl);
		
		gbl.gridx = 0;
		gbl.gridy = 2;
		menuPanel.add(clearButton, gbl);
		
		gbl.gridx = 1;
		gbl.gridy = 2;
		menuPanel.add(thicknessBox, gbl);
		
		gbl.gridx = 0;
		gbl.gridy = 3;
		menuPanel.add(colorButton, gbl);
		
		gbl.gridx = 1;
		gbl.gridy = 3;
		gbl.fill = GridBagConstraints.NONE;
		menuPanel.add(colorTxt, gbl);
		
		gbl.gridx = 0;
		gbl.gridy = 4;
		gbl.fill = GridBagConstraints.HORIZONTAL;
		menuPanel.add(colorBCKButton, gbl);
		
		gbl.gridx = 1;
		gbl.gridy = 4;
		gbl.fill = GridBagConstraints.NONE;
		menuPanel.add(colorbcktxt, gbl);
		
				
		
		
		
	}


}
