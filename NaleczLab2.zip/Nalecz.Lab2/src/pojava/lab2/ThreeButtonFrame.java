package pojava.lab2;

import java.awt.Color;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ThreeButtonFrame extends JFrame {

	public ThreeButtonFrame() throws HeadlessException {
		super();
		setSize(240, 180); // ustawienie rozmiaru okna 240x180
		
		JPanel panel1 = new JPanel();
		
		JButton button1 = new JButton("Przycisk1"); // pierwszy przycisk
		ActionListener changeTXT = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				button1.setText("Klikniety"); // po kliknieciu zmienia tekst na guziku
			}
		};
		button1.addActionListener(changeTXT); // dodanie listenera do button1
		panel1.add(button1); // dodanie guzika do panel1
		
		
		
		JButton button2 = new JButton("Przycisk2");
		ActionListener changeColor = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				button2.setBackground(Color.red); // po kliknieciu ustawia kolor guzika na czerwony
				
			}
		};
		button2.addActionListener(changeColor); // dodanie listenera do button2
		panel1.add(button2);
		
		
		
		JButton button3 = new JButton("Przycisk3");
		ActionListener exitListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				System.exit(0); // po kliknieciu wylacza program
			}
		};
		button3.addActionListener(exitListener); // dodanie listenera do button3
		panel1.add(button3);
		
		this.add(panel1); // dodanie panel1 do framu ThreeButtonFrame
		
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	

	public ThreeButtonFrame(GraphicsConfiguration gc) {
		super(gc);
		setSize(640, 480);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	public ThreeButtonFrame(String title) throws HeadlessException {
		super(title);
		setSize(640, 480);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	public ThreeButtonFrame(String title, GraphicsConfiguration gc) {
		super(title, gc);
		setSize(640, 480);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	public static void main(String[] args) {
		
		ThreeButtonFrame frame = new ThreeButtonFrame();
		frame.setVisible(true);
		

	}

}
