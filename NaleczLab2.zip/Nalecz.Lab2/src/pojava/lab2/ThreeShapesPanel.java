package pojava.lab2;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import pojava.lab2.CloseableFrame;


public class ThreeShapesPanel extends JPanel {
	
	Random r1 = new Random(); // obiekt klasy random do losowania kolorow

	Color color1 = new Color(r1.nextInt(251), r1.nextInt(251), r1.nextInt(251)); // losowanie 3 kolorow
	Color color2 = new Color(r1.nextInt(251), r1.nextInt(251), r1.nextInt(251));
	Color color3 = new Color(r1.nextInt(251), r1.nextInt(251), r1.nextInt(251));

	public void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		
		g.setColor(color1); // ustawienie koloru
		g.fillRect(50, 50, 100, 100);	// ustawienie w oknie i podanie wymiarow prostokata
		
		g.setColor(color2);
		g.fillOval(150, 250, 100, 100); // kolo
		
		g.setColor(color3);
		g.fillArc(250, 50, 100, 150, 100, 100);		// luk
	}

	public static void main(String[] args) {
		
		CloseableFrame frame = new CloseableFrame();
		
		ThreeShapesPanel panel = new ThreeShapesPanel(); // panel dla figur
		panel.setBackground(null);
		
		frame.add(panel); // dodanie panel do frame
		
		JPanel panel2 = new JPanel(); // panel dla komponentow 
		
		JButton button = new JButton("Guziczek");
		panel2.add(button); // dodanie guzika do panel2
		
		JLabel label = new JLabel("Etykieta");
		panel2.add(label);	// dodanie etykiety
		
		JTextField txt = new JTextField("Pole txt");
		panel2.add(txt);	// dodanie pola tekstowego
		
		JPasswordField pswrd = new JPasswordField();
		panel2.add(pswrd);	// dodanie pola do wpisania hasla
		
		panel2.setLayout(new GridLayout(4,1)); // ustawienie guzikow jeden pod drugim za pomoca grida
		
		frame.add(panel2); // dodanie panel2 do frame
		
		
		frame.setLayout(new GridLayout(1,2)); // ustawienie panel1 i panel2 jeden obok siebie
		frame.setVisible(true); // nie jest to potrzebne poniewaz jest to ustawione w konstruktorze

	}

}
