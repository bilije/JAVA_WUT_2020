package pojava.lab2;

import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;

import javax.swing.JFrame;

public class CloseableFrame extends JFrame {

	public CloseableFrame() throws HeadlessException {
		super();
		setSize(640, 480); // ustawienie okienka 640x480
		setVisible(true);	// okienko jest widoczne
		setDefaultCloseOperation(DISPOSE_ON_CLOSE); // po wylaczeniu okna, program zatrzymuje sie
	}

	public CloseableFrame(GraphicsConfiguration gc) {
		super(gc);
		setSize(640, 480);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	public CloseableFrame(String title) throws HeadlessException {
		super(title);
		setSize(640, 480);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	public CloseableFrame(String title, GraphicsConfiguration gc) {
		super(title, gc);
		setSize(640, 480);
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	public static void main(String[] args) {
		
		CloseableFrame okno = new CloseableFrame(); // obiekt powyzszej klasy
	}

}
