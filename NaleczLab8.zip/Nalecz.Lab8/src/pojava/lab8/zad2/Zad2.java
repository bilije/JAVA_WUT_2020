package pojava.lab8.zad2;

import java.awt.Color;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Scanner;

import javax.imageio.ImageIO;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.w3c.dom.Text;

import com.orsonpdf.PDFDocument;
import com.orsonpdf.PDFGraphics2D;
import com.orsonpdf.PDFHints;
import com.orsonpdf.Page;

import pojava.lab8.zad1.Point;

public class Zad2 {
	
	static List<String> lista1 = new ArrayList<String>();

	private static XYDataset createDataset() {
		
		List<Point> dane = new ArrayList<Point>();
		
		File inputFile = new File("dane.txt");
		
		//Scanner in;
		try {
		Scanner in = new Scanner(inputFile);
		while(in.hasNextLine()) {
			
			Scanner check = new Scanner(in.nextLine());
			
			while(check.hasNext()) {
				//System.out.println(check.next());
				try {
					lista1.add(check.next());
				}
				catch(NoSuchElementException e) {
					e.printStackTrace();
				}
			}
		}
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		for(int i = 0; i < lista1.size();i+=3) {
			
			dane.add(new Point(Integer.parseInt(lista1.get(i)),
					Integer.parseInt(lista1.get(i+1)),Integer.parseInt(lista1.get(i+2))));
			
		}
		
		
		
		
		Random rand = new Random();
		
		/*for(int i = 0; i < 10 ; i++) {
			System.out.println(rand.nextInt(20)+ " "+rand.nextInt(20)+ " "+ rand.nextInt(20));
		}*/
		
		XYSeries series1 = new XYSeries("Seria1");
		for(int i = 0; i < dane.size(); i++) {
			series1.add(dane.get(i).getX(), dane.get(i).getY());
		}
		
		
		XYSeries series2 = new XYSeries("Seria2");
		for(int i = 0; i < dane.size(); i++) {
			series2.add(dane.get(i).getX(), dane.get(i).getZ());
		}

		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(series1);
		dataset.addSeries(series2);
		
		
		return dataset;
	}
	
	 private static JFreeChart createChart(XYDataset dataset) {
		 
		 JFreeChart chart = ChartFactory.createXYLineChart(
					"Wykres XY",//Tytul
					"O� X", // opisy osi
					"O� Y", 
					dataset, // Dane 
					PlotOrientation.VERTICAL, // Orjentacja wykresu /HORIZONTAL
					true, // legenda
					true, // tooltips
					false
				);
		 return chart;
	 }
	
	
	public static void main(String[] args) {
		  	JFreeChart chart = createChart(createDataset());
	        PDFDocument pdfDoc = new PDFDocument();
	        pdfDoc.setTitle("test");
	        pdfDoc.setAuthor("Tomasz Na��cz");
	        Page page1 = pdfDoc.createPage(new Rectangle(612, 468));
	        Page page2 = pdfDoc.createPage(new Rectangle(612, 468));
	        Page page3 = pdfDoc.createPage(new Rectangle(612, 468));
	        
	        PDFGraphics2D g1 = page1.getGraphics2D();
	        g1.setRenderingHint(PDFHints.KEY_DRAW_STRING_TYPE, 
	                PDFHints.VALUE_DRAW_STRING_TYPE_VECTOR);
	        chart.draw(g1, new Rectangle(0, 0, 612, 468));
	        
	        
	        PDFGraphics2D g2 = page2.getGraphics2D();
	        g2.setRenderingHint(PDFHints.KEY_DRAW_STRING_TYPE, 
	                PDFHints.VALUE_DRAW_STRING_TYPE_VECTOR);
	        
	        g2.setColor(Color.black);
	        g2.drawString("X",50, 50);
	        g2.drawString("Y1", 100, 50);
	        g2.drawString("Y2", 150,50);
	        
	        int counter = 75;
	        
	        for(int i=0; i < lista1.size(); i+=3) {
	        	g2.drawString(lista1.get(i), 50, counter);
	        	g2.drawString(lista1.get(i+1), 100, counter);
	        	g2.drawString(lista1.get(i+2), 150, counter);
	        	
	        	counter+=25;
	        }
	        
	        
	        PDFGraphics2D g3 = page3.getGraphics2D();
	        g3.setRenderingHint(PDFHints.KEY_DRAW_STRING_TYPE, 
	                PDFHints.VALUE_DRAW_STRING_TYPE_VECTOR);
	        
	        BufferedImage image2 = null;
			
			
			File inputFile = new File("obrazek.png");
								
			try {
				image2 = ImageIO.read(inputFile);
			} catch(IOException ex) {
				System.out.println(ex.getMessage());
			}
	        
			
			g3.drawImage(image2, 0, 0,300,300, null );
			g3.setColor(Color.black);
	        g3.drawLine(400, 300, 500, 200);
	        g3.fillOval(400, 300, 100, 50);
	        
	        File f = new File("test.pdf");
	        pdfDoc.writeToFile(f);

	}

}
