package pojava.lab8.zad1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Scanner;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class Zad1 {

	public static void main(String[] args) {
		
		List<Point> dane = new ArrayList<Point>();
		
		List<String> lista1 = new ArrayList<String>();
		
		File inputFile = new File("dane.txt");
		
		//Scanner in;
		try {
		Scanner in = new Scanner(inputFile);
		while(in.hasNextLine()) {
			
			Scanner check = new Scanner(in.nextLine());
			
			while(check.hasNext()) {
				//System.out.println(check.next());
				try {
					lista1.add(check.next());
				}
				catch(NoSuchElementException e) {
					e.printStackTrace();
				}
			}
		}
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		for(int i = 0; i < lista1.size();i+=3) {
			
			dane.add(new Point(Integer.parseInt(lista1.get(i)),
					Integer.parseInt(lista1.get(i+1)),Integer.parseInt(lista1.get(i+2))));
			
		}
		
		
		
		
		Random rand = new Random();
		
		/*for(int i = 0; i < 10 ; i++) {
			System.out.println(rand.nextInt(20)+ " "+rand.nextInt(20)+ " "+ rand.nextInt(20));
		}*/
		
		XYSeries series1 = new XYSeries("Seria1");
		for(int i = 0; i < dane.size(); i++) {
			series1.add(dane.get(i).getX(), dane.get(i).getY());
		}
		
		
		XYSeries series2 = new XYSeries("Seria2");
		for(int i = 0; i < dane.size(); i++) {
			series2.add(dane.get(i).getX(), dane.get(i).getZ());
		}

		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(series1);
		dataset.addSeries(series2);
		
		JFreeChart chart = ChartFactory.createXYLineChart(
				"Wykres XY",//Tytul
				"O� X", // opisy osi
				"O� Y", 
				dataset, // Dane 
				PlotOrientation.VERTICAL, // Orjentacja wykresu /HORIZONTAL
				true, // legenda
				true, // tooltips
				false
			);
		
		ChartFrame frame = new ChartFrame("XYLine Chart",chart);
		frame.setVisible(true);
		frame.setSize(800,600);
		
	}

}
